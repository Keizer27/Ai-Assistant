export const AI_API_KEY = "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";
export const AI_ENDPOINT = "https://api.deepseek.com/v1/chat/completions";